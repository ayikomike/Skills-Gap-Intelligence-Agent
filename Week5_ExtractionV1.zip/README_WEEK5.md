# Week 5 — Extraction Pipeline v1

Combined gazetteer (spaCy `PhraseMatcher`) + `EntityRuler` matched against the Week 4 skills and occupation taxonomy.

## Setup

```bash
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install --upgrade pip
pip install pandas spacy pyyaml openpyxl
python -m spacy download en_core_web_sm